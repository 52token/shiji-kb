# 太史公文笔提炼实验

本实验项目从《史记》130篇中提炼司马迁（太史公）的写作风格，形成可复用的AI写作技能。

---

## 快速开始（5分钟上手）

### 方法一：最简单触发（适合Claude Code）

如果你在使用 **Claude Code**（claude.ai/code），AI会自动找到这个SKILL文件夹并使用。

**直接对AI说**：
```
用太史公文笔改写下面这段话：
[把你的现代文字粘贴在这里]
```

AI会自动读取 `SKILL.md` 并执行三步转换。

---

### 方法二：安装到Claude Skills目录（通用方法）

**第1步**：下载并复制整个目录到配置目录

```bash
# 方式A：如果已clone本项目
cp -r labs/sima-qian-style ~/.config/claude-code/skills/

# 方式B：直接下载ZIP包（无需clone完整项目）
# 1. 访问 https://github.com/baojie/shiji-kb/tree/main/labs/sima-qian-style
# 2. 点击绿色 "Code" 按钮 → "Download ZIP"
# 3. 解压后复制到：
#    - Claude Code: ~/.config/claude-code/skills/
#    - Codex: ~/.codex/skills/
```

目录结构：
- `SKILL.md` （主SKILL，包含YAML元数据）
- `references/` （子技能，按需加载）
- `evals/` （示例）

**第2步**：重启AI或刷新技能列表

**第3步**：直接使用
```
用太史公文笔改写下面这段话：
[你的现代文字]
```

AI会自动找到并使用这个SKILL。

---

### 方法三：手动粘贴SKILL（适合其他AI）

如果你使用的AI不支持SKILL文件（如网页版ChatGPT），需要手动提供主SKILL：

**第1步**：打开并复制 [SKILL.md](SKILL.md) 全文

**第2步**：粘贴给AI并说明你的需求

```
【SKILL：太史公文笔风格】
[粘贴 SKILL.md 全文]

请用这个SKILL改写下面这段话：
[你的现代文字]
```

**注意**：SKILL.md 会在需要时自动引用 `references/` 中的子技能文档。

---

### AI会自动做什么

1. **第0步**：将现代词汇古化（AI→智能之术、项目→事）
2. **第1步**：转换为文言文（删除"的地得"，改写句式）
3. **第2步**：应用太史公风格（开篇定式、列举式、简短有力）

### 示例对比

**你输入**：
> shiji-kb是一个开源的古籍知识工程项目。用AI将《史记》130篇转化为结构化知识。

**AI输出**：
> shiji-kb者，开源古籍学问事业也。
>
> 以智能之术，化《史记》百三十篇为知识经纬。
>
> 类十有八，注近十万；事三千馀，系七千馀。

**三大变化**：
- ✅ 现代词古化：知识工程→学问事业，AI→智能之术
- ✅ 文言化：删除"的"，改"是"为"者...也"
- ✅ 太史公风格：句子短促有力，数字倒装（18类→类十有八）

### 查看完整示例

- [示例01：乔布斯列传](evals/example-01-jobs.md) - 人物传记
- [示例02：shiji-kb记](evals/example-02-shiji-kb-full.md) - 项目介绍（完整教学版）
- [示例03：葛底斯堡演讲](evals/example-03-gettysburg.md) - 经典演讲（政治文献）
- [示例04：论Skill之道](evals/example-04-skill-concept.md) - 技术概念解释
- [示例05：职场会议记](evals/example-05-workplace-rant.md) - 职场吐槽（阿里黑话转太史公文风）

---

## 项目目标

将太史公的**文笔形式**（而非内容）系统化、模板化，供现代写作参考，包括：

- 句法结构（短句、层递、因果承转）
- 叙事节奏（白描、惜墨如金、跳跃剪辑）
- 修辞手法（反复、对仗、先抑后扬）
- 人物刻画（细节定性格、行为即性格）
- 议论风格（太史公曰模式、寓褒贬于叙事）

## 方法论来源

本项目参考 [inf-xu/author-style-skills](https://github.com/inf-xu/author-style-skills) 的方法论：

1. **风格提取框架**: 优先"语言、句法、修辞与叙述节奏"，避免内容复用
2. **文体分流系统**: 根据素材性质分为列传体、本纪体、论赞体
3. **双重限制**:
   - ❌ 不复述《史记》原文内容
   - ❌ 不模拟司马迁的历史观点
   - ✅ 只学习形式特征

## 目录结构（标准Claude Skill架构）

```
sima-qian-style/
├── SKILL.md                       # 主SKILL（包含YAML frontmatter）
├── references/                    # 子技能（按需加载）
│   ├── modern-terms.md           # 现代名词古化词典
│   ├── classical-chinese.md      # 白话转文言规则
│   └── style-features.md         # 太史公文笔特征
├── evals/                         # 测试用例/示例
│   ├── example-01-jobs.md        # 乔布斯列传
│   ├── example-02-shiji-kb-full.md  # shiji-kb记
│   ├── example-03-gettysburg.md  # 葛底斯堡演讲
│   └── example-04-skill-concept.md  # 论Skill之道
└── README.md                      # 本文档
```

## 技能分层

本项目采用**三层技能架构**：

```
┌─────────────────────────────────────────────────┐
│  现代白话文输入                                   │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│  第0层：references/modern-terms.md               │
│  ├─ 学术类词典（知识图谱→知识经纬）              │
│  ├─ 科技类词典（AI Agent→智能体）                │
│  ├─ 管理类词典（项目→事）                        │
│  └─ 组合词处理规则                               │
└────────────────┬────────────────────────────────┘
                 │ 半古化白话
                 ▼
┌─────────────────────────────────────────────────┐
│  第1层：references/classical-chinese.md          │
│  ├─ 虚词转换（的地得→删除）                      │
│  ├─ 动词转换（是有→为具）                        │
│  ├─ 代词转换（我你他→余汝其）                    │
│  ├─ 连词/副词转换                                │
│  └─ 数字/时间转换                                │
└────────────────┬────────────────────────────────┘
                 │ 标准文言文
                 ▼
┌─────────────────────────────────────────────────┐
│  第2层：SKILL.md + references/style-features.md  │
│  ├─ 开篇定式（X者，Y也）                         │
│  ├─ 列举式（其所为有二）                         │
│  ├─ 层递并列、设问自答                           │
│  ├─ 先抑后扬、白描手法                           │
│  └─ 太史公曰（引古联今评判）                     │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│  太史公风格成文                                   │
└─────────────────────────────────────────────────┘
```

本项目采用**三层技能架构**：

### 第0层：现代名词古化（子技能）
- **文件**：`references/modern-terms.md`
- **功能**：现代学术/科技/管理名词 → 古代汉语表达
- **内容**：7大类名词词典（学术、科技、管理、时间、抽象、教育、具体物品）、组合词处理规则
- **调用者**：被 `references/classical-chinese.md` 调用（第0步）
- **独立使用**：可单独用于专有名词的古化翻译

**典型转换**：
- 知识图谱 → 知识经纬
- AI Agent → 智能体
- 技能文档 → 技艺文
- 结构化知识 → 条理之学

### 第1层：白话转文言（基础层）
- **文件**：`references/classical-chinese.md`
- **功能**：现代汉语 → 文言文（完整转换）
- **内容**：9大类转换规则（含调用现代名词古化）、5大句式、自检清单
- **依赖**：调用 `references/modern-terms.md`（第0步）
- **独立使用**：可单独用于文言文翻译

**转换顺序**：
1. 第0步：现代名词古化
2. 第1-8步：虚词、动词、代词、连词、副词、量词、数字、时间表达转换

### 第2层：太史公曰（高级层）
- **文件**：`SKILL.md` + `references/style-features.md`
- **功能**：文言文 → 太史公文风
- **依赖**：调用 `references/classical-chinese.md`（含现代名词古化）作为第一步
- **内容**：太史公特有句式、修辞、人物刻画技法

**应用技法**：开篇定式、列举式、层递并列、设问自答、先抑后扬、白描、对话动作穿插、跳跃剪辑

## 核心特征（8大维度）

详见 [references/style-features.md](references/style-features.md)：

1. **句法结构**: 开篇定式、简短断言、层递并列、因果承转
2. **叙事节奏**: 白描手法、对话精准截取、跳跃式剪辑
3. **修辞手法**: 反复强调、先抑后扬、排比对仗、设问自答
4. **人物刻画**: 关键细节定性格、行为即性格、他人之口借力
5. **议论特征**: 太史公曰模式、褒贬寓于叙事
6. **文体分类**: 本纪、列传、自序论赞
7. **自检清单**: 7项质量检查标准
8. **句式模板库**: 常用开篇、转折、评价、议论句式

## 使用方法

### 完整转换流程

```
现代白话文
    ↓
【第0步】现代名词古化（references/modern-terms.md）
    ↓
半古化白话（名词已古化，句式仍现代）
    ↓
【第1步】白话转文言（references/classical-chinese.md）
    ↓
标准文言文（无现代痕迹）
    ↓
【第2步】太史公文风（SKILL.md）
    ↓
太史公风格成文
```

### 1. 作为 AI 写作技能

**选项A：一步到位**（推荐）
- 直接使用 [SKILL.md](SKILL.md)
- 会自动调用完整三层架构（自动读取 `references/`）
- 触发词："用太史公文笔写XXX"

**选项B：分步执行**（教学用）
1. 先用 [references/modern-terms.md](references/modern-terms.md) 处理专有名词
2. 再用 [references/classical-chinese.md](references/classical-chinese.md) 转为文言
3. 最后用 [SKILL.md](SKILL.md) 应用风格

**选项C：单独使用基础层**
- 只用 [references/classical-chinese.md](references/classical-chinese.md)（含现代名词古化）
- 适合需要标准文言文但不需要太史公风格的场景

### 2. 作为写作参考

阅读 [references/style-features.md](references/style-features.md)，学习具体句式和修辞技巧，手工润色文章。

### 3. 查看完整示例

- [evals/example-01-jobs.md](evals/example-01-jobs.md) - 乔布斯列传（人物传记体）
- [evals/example-02-shiji-kb-full.md](evals/example-02-shiji-kb-full.md) - shiji-kb记（项目介绍，333字完整版）
- [evals/example-03-gettysburg.md](evals/example-03-gettysburg.md) - 葛底斯堡演讲（经典政治演讲，272字）
- [evals/example-04-skill-concept.md](evals/example-04-skill-concept.md) - 论Skill之道（技术概念论说）
- [evals/example-05-workplace-rant.md](evals/example-05-workplace-rant.md) - 职场会议记（阿里黑话转太史公文风）

每个示例都包含：
- 完整的三步转换流程
- 每一步的详细转换表
- 技法应用统计
- 常见陷阱警示

## 语料来源

- **一手语料**: 《史记》130篇完整标注文本（本项目 `chapter_md/` 目录）
- **重点分析篇目**:
  - [项羽本纪](../../chapter_md/007_项羽本纪.tagged.md)（列传体经典）
  - [太史公自序](../../chapter_md/130_太史公自序.tagged.md)（议论体、元叙事）
  - 李将军列传（人物刻画典范）
  - 货殖列传（经济史写法）

## 与鲁迅文笔的对比

| 维度 | 太史公（司马迁） | 鲁迅 |
|------|----------------|------|
| **句式** | 短句为主，古文句法 | 长句、分号多，民国白话 |
| **叙事** | 跳跃式剪辑，惜墨如金 | 密集细节，心理刻画丰富 |
| **修辞** | 排比对仗，反复强调 | 反讽、隐喻、"字字是血" |
| **议论** | 寓褒贬于叙事，太史公曰 | 直白犀利，杂文讽刺 |
| **适用场景** | 历史传记、人物小传 | 讽刺杂文、文化批评 |

## 后续计划

- [x] 提炼核心风格特征（8大维度）
- [x] 编写 SKILL 提示词
- [x] 创建第一个完整示例（乔布斯列传）
- [ ] 补充更多示例（科技人物、历史事件、当代议题）
- [ ] 增加"本纪体""论赞体"专用模板
- [ ] 分析《史记》中的特殊句式（如"太史公曰"引经据典的结构）
- [ ] 对比《汉书》班固文笔与太史公的差异

## 参考资料

- 《史记》全文（130篇）- 本项目语料库
- [inf-xu/author-style-skills](https://github.com/inf-xu/author-style-skills) - 方法论来源

---

**版本**: v1.0
**创建日期**: 2026-03-20
**作者**: [baojie](https://github.com/baojie) - 基于[《史记》知识库项目](https://github.com/baojie/shiji-kb)提炼
**项目地址**: https://github.com/baojie/shiji-kb/tree/main/labs/sima-qian-style
**许可**: CC BY-NC-SA 4.0
